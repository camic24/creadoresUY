module.exports = {
    apiurl  : "https://creadoresuyapiback.web.elasticloud.uy"
  }
  
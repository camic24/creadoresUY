import { PlanPost } from "./PlanPost";

export class PlanAndNickname {
    nickname: string;
    pandB: PlanPost;
}
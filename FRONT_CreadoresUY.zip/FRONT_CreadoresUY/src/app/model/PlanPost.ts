export class PlanPost {
    name: string;
    description: string;
    price: number;
    image: string;
    subscriptionMsg: string;
    welcomeVideoLink: string;
    benefits: string[];
}
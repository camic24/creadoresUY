export class SuscriptionPlans{
    constructor(
            creatorId:       number,
            idPlan:          number,
            namePlan:        string,
            descriptionPlan: string,
            imagen:          string,
            price:           number,
    ){}
}
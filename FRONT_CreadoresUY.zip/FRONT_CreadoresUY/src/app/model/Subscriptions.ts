export class Subscriptions{
    name:string;
    id:number;
    profileImage:string;
    subscriberDate:Date
}
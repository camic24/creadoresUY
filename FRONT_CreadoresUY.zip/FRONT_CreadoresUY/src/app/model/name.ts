export class name{
    name:string;

    constructor(name:string){
        this.name = name;
    }
}
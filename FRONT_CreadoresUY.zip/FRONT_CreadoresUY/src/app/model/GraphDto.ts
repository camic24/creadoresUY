export class GraphDto {
    xValue: any;
    yValue: any;
}
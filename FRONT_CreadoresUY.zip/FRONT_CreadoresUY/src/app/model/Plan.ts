export class Plan {
    idPlan: number;
    name: string;
    description: string;
    price: number;
    image: string;
    subscriptionMsg: string;
    welcomeVideoLink: string;
    benefits: string[];
}
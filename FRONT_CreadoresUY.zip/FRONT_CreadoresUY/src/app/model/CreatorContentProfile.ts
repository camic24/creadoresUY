import { CreatorContentProfileAuthorized } from "./CreatorContentProfileAuthorized";

export class CreatorContentProfile {
    results: number;
    follow: boolean;
    contentsAndBool: CreatorContentProfileAuthorized[];
}
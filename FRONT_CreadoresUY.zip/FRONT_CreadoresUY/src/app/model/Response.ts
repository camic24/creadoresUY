export class Response<T> {
    Obj: T;
    Success: boolean;
    CodStatus: number;
    Message:   string[];
  }
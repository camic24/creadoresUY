export class PlanBasic {
    id:number;
    name:string;
}
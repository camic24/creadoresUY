export class dto{
    idUser: number;
    nickName: string;
    idPlan: number;
    externalPaymentId: string;
    paymentAmount: number;
}
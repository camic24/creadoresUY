export class CategoryComplet {
    id: number;
    deleted: boolean;
    Name: string;
}
import { Plan } from "./Plan";

    export class CreatorPlansToUser {
        subscribedTo: number;
        plans: Plan[];
    }
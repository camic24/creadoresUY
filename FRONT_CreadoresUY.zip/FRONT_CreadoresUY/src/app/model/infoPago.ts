export class infoPago {
    nombreTitular: string;
    numeroDeCuenta: number;
    nombreEntidadFinanciera: string;

    constructor(){}
}
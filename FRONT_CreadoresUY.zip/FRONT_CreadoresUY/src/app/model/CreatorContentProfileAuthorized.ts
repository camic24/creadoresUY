import { CreatorContent } from "./CreatorContent";

export class CreatorContentProfileAuthorized {
    authorized: boolean;
    content: CreatorContent;
}
export class CreatorChatDto {
    idCreator: string;
    idUser: string;
    imgProfile: string;
    name: string;
}
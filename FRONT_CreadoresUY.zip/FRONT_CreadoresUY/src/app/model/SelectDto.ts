export class SelectDto {
    num: number;
    name: string;
    constructor(_num: number, _name: string) {
        this.num = _num;
        this.name = _name;
    }


}



export class Payment {
    nickname: string;
    amount: Number;
    monthYear: string;
}
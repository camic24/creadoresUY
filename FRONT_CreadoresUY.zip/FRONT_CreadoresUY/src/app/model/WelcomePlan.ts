export class WelcomePlan {
    subscriptionMsg:string;
    welcomeVideoLink:string;
}
export interface Chat {
    usuario: string
}
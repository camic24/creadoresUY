﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Share.Enums
{
    public enum TipoCategory
    {
        Arte = 1, 
        Comida = 2, 
        Trading = 3,
        Música=4
    }
}

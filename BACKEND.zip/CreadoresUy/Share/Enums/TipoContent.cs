﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Share.Enums
{
    public enum TipoContent
    {
        Text = 1,
        Image =2,
        Video = 3,
        Audio = 4,
        Link = 5
    }
}
